﻿using IdentityDemoV2.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace IdentityDemoV2.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        //public IActionResult Index()
        //{
        //    return Content("Welcome Admin! You are logged in.");
        //}

        private readonly UserManager<ApplicationUser> _userManager;

        public AdminController(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            // Get the current logged-in user
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Pass user details to the View
            ViewBag.FullName = user.FullName;
            ViewBag.Email = user.Email;

            return View();
        }
    }
}
