﻿using IdentityDemoV2.Models;
using IdentityDemoV2.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace IdentityDemoV2.Controllers
{
    [Authorize]  // Only logged-in users can access
    public class DashboardController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public DashboardController(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            // Get the current logged-in user
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Pass user details to the View
            ViewBag.FullName = user.FullName;
            ViewBag.Email = user.Email;

            return View();
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AdminOnlyAction()
        {
            return Content("Welcome Admin! Your action is executed.");
        }

    }
}
