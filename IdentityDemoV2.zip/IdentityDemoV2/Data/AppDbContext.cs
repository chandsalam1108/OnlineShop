﻿using IdentityDemoV2.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace IdentityDemoV2.Data
{
    public class ChandDbContext : IdentityDbContext<ApplicationUser>
    {
        public ChandDbContext(DbContextOptions<ChandDbContext> options)
            : base(options)
        {
        }
    }
}
