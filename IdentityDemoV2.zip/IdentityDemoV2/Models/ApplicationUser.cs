﻿using Microsoft.AspNetCore.Identity;

namespace IdentityDemoV2.Models
{
    //Model class represents SQL table and properties are mapped to columns.
    public class ApplicationUser : IdentityUser
    {
        public string FullName { get; set; }
    }
}
