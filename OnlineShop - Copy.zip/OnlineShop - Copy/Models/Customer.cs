﻿using System.ComponentModel.DataAnnotations;

namespace OnlineShop.Models
{
    public class Customer
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string FullName { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required, StringLength(200)]
        public string Address { get; set; }

        [Phone]
        public string Phone { get; set; }
    }

}
