﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OnlineShop.Data;
using OnlineShop.Models;
using Kendo.Mvc.UI; // Required for DataSourceRequest
using Kendo.Mvc.Extensions;
using Microsoft.Extensions.Caching.Memory; // Required for ToDataSourceResultAsync

namespace OnlineShop.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context;

        private readonly IMemoryCache _cache;

        private const string CacheKey = "all_products";

        public ProductsController(ApplicationDbContext context, IMemoryCache cache)
        {
            _context = context;
            _cache = cache;
        }

        // GET: Products
        // This action now simply returns the view. The Kendo UI Grid will load its data via AJAX.
        public IActionResult Index()
        {
            return View();
        }

        // POST: Products/Products_Read
        // This action handles the AJAX requests from the Kendo UI Grid for data binding,
        // including paging, sorting, and filtering.
        [HttpPost] // Kendo UI Grid typically sends POST requests for data operations
        public async Task<IActionResult> GetAll([DataSourceRequest] DataSourceRequest request)
        {
            if (!_cache.TryGetValue(CacheKey, out List<Product> products))
            {
                //DB Call
                products = _context.Products.ToList();

                // Set cache options
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromMinutes(30));

                _cache.Set(CacheKey, products, cacheEntryOptions);
            }
            
            // Apply Kendo UI DataSourceRequest operations (paging, sorting, filtering)
            // and convert the result to a DataSourceResult object.
            DataSourceResult result = await products.ToDataSourceResultAsync(request);

            // Return the result as JSON, which Kendo UI Grid understands.
            return Json(result);
        }

        // GET: Products/Details/5
        // Displays the details of a specific product.
        [HttpGet]
        public async Task<IActionResult> Details(int? id) // 'id' is nullable
        {
            if (id == null)
            {
                return NotFound(); // Return 404 if no ID is provided
            }

            // Find the product by ID
            var product = await _context.Products
                .SingleOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound(); // Return 404 if product is not found
            }

            return View(product); // Pass the product to the view
        }

        // GET: Products/Create
        // Displays the form to create a new product.
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        // Handles the form submission for creating a new product.
        [HttpPost]
        [ValidateAntiForgeryToken] // Protects against cross-site request forgery attacks
        public async Task<IActionResult> Create([Bind("Id,Name,Description,Price,StockQuantity")] Product product)
        {
            if (ModelState.IsValid) // Check if the model state is valid based on data annotations
            {
                _context.Add(product); // Add the new product to the database context
                await _context.SaveChangesAsync(); // Save changes to the database

                _cache.Remove(CacheKey);

                return RedirectToAction(nameof(Index)); // Redirect to the Index page after successful creation
            }
            return View(product); // If model state is invalid, return the view with the product to show validation errors
        }

        // GET: Products/Edit/5
        // Displays the form to edit an existing product.
        [HttpGet]
        public async Task<IActionResult> Edit(int? id) // 'id' is nullable
        {
            if (id == null)
            {
                return NotFound(); // Return 404 if no ID is provided
            }

            // Find the product by ID
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound(); // Return 404 if product is not found
            }

            return View(product); // Pass the product to the view
        }

        // POST: Products/Edit/5
        // Handles the form submission for updating an existing product.
        // Changed from [HttpPut] to [HttpPost] for standard HTML form submission.
        [HttpPost]
        [ValidateAntiForgeryToken] // Protects against cross-site request forgery attacks
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description,Price,StockQuantity")] Product product)
        {
            if (id != product.Id)
            {
                return NotFound(); // Return 404 if the ID in the URL doesn't match the product ID
            }

            if (ModelState.IsValid) // Check if the model state is valid
            {
                try
                {
                    _context.Update(product); // Update the product in the database context
                    await _context.SaveChangesAsync(); // Save changes to the database

                    _cache.Remove(CacheKey);
                }
                catch (DbUpdateConcurrencyException) // Handle concurrency conflicts
                {
                    if (!ProductExists(product.Id)) // Check if the product still exists
                    {
                        return NotFound(); // Return 404 if product was deleted by another user
                    }
                    else
                    {
                        throw; // Re-throw other concurrency exceptions
                    }
                }
                return RedirectToAction(nameof(Index)); // Redirect to the Index page after successful update
            }
            return View(product); // If model state is invalid, return the view with the product to show validation errors
        }

        // GET: Products/Delete/5
        // Displays a confirmation page before deleting a product.
        [HttpGet]
        public async Task<IActionResult> Delete(int? id) // 'id' is nullable
        {
            if (id == null)
            {
                return NotFound(); // Return 404 if no ID is provided
            }

            // Find the product by ID
            var product = await _context.Products
                .FirstOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound(); // Return 404 if product is not found
            }

            return View(product); // Pass the product to the view
        }

        // POST: Products/Delete/5
        // Handles the actual deletion of a product after confirmation.
        [HttpPost, ActionName("Delete")] // ActionName specifies the action to be invoked by the form
        [ValidateAntiForgeryToken] // Protects against cross-site request forgery attacks
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id); // Find the product to delete
            if (product != null)
            {
                _context.Products.Remove(product); // Remove the product from the database context
            }

            await _context.SaveChangesAsync(); // Save changes to the database

            _cache.Remove(CacheKey);

            return RedirectToAction(nameof(Index)); // Redirect to the Index page after deletion
        }

        // Helper method to check if a product exists.
        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.Id == id);
        }
    }
}
